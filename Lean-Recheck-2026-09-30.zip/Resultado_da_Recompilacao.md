# Recompilação do caso geral — 30 de setembro de 2026

**Resultado: os oito módulos originais e a auditoria final compilaram com código de saída 0.**

A declaração `VietorisOrdinals.ordinal_full` verifica, para todo ordinal real de mathlib com `ω < a < ω₁`, segunda enumerabilidade, a propriedade de Lindelöf, não σ-compacidade e falha da propriedade de Menger para o espaço de funções de imagem compacta com a topologia especificada no artigo.

## Execução realizada

- Compilador: Lean (version 4.19.0, x86_64-w64-windows-gnu, commit 6caaee842e94, Release).
- Revisão do projeto: `d2e73e4b297f98592fa7a6d2fe36695165e009fa`.
- Os 14 arquivos de fonte/configuração foram recuperados dos bytes do Git e conferidos com o manifesto de hashes.
- As nove revisões das dependências e a ausência de alterações nos seus fontes rastreados foram conferidas.
- Todos os módulos do projeto foram recompilados separadamente, em ordem de dependência, com as importações originais, numa pasta inicialmente sem arquivos `.olean` do projeto.
- Não houve combinação dos módulos nem mudança nos corpos das provas.
- O compilador foi chamado diretamente com `-j1` e `LEAN_PATH` explícito. A execução não foi uma chamada a `lake build` ou ao gerenciador `elan`.
- As bibliotecas compiladas das dependências foram reutilizadas. Lean e mathlib não foram recompilados dos seus fontes.
- Os hashes dos fontes foram conferidos novamente ao final e permaneceram idênticos.

| Módulo | Saída | Segundos |
|---|---:|---:|
| VietorisOrdinals/Model | 0 | 384.67 |
| VietorisOrdinals/Diagonal | 0 | 54.75 |
| VietorisOrdinals/Countability | 0 | 59.83 |
| VietorisOrdinals/Obstruction | 0 | 77.31 |
| VietorisOrdinals/Menger | 0 | 74.61 |
| VietorisOrdinals/Ordinals | 0 | 359.52 |
| VietorisOrdinals/Results | 0 | 70.64 |
| VietorisOrdinals | 0 | 56.98 |
| FullAudit.lean | 0 | 524.51 |

## Auditoria de axiomas

- `VietorisOrdinals.second_countable`: `propext`, `Classical.choice`, `Quot.sound`.
- `VietorisOrdinals.not_sigmaCompact`: `propext`, `Classical.choice`, `Quot.sound`.
- `VietorisOrdinals.not_menger`: `propext`, `Classical.choice`, `Quot.sound`.
- `VietorisOrdinals.ordinal_main`: `propext`, `Classical.choice`, `Quot.sound`.
- `VietorisOrdinals.ordinal_full`: `propext`, `Classical.choice`, `Quot.sound`.
- `VietorisOrdinals.ordinal_subsets_countable`: `propext`, `Classical.choice`, `Quot.sound`.

As seis declarações auditadas dependem somente de `propext`, `Classical.choice` e `Quot.sound`. Não há `sorryAx`, axioma matemático adicional ou axioma de confiança em computação nativa nas listas transitivas. `FullAudit.lean` também verifica a conclusão explícita, a instância da topologia da ordem e o enunciado não-Menger.

## Correspondência e limites

A releitura dos fontes confirma que o portador exige a compacidade da imagem efetiva, que a topologia é gerada por restrições abertas da imagem e de finitas coordenadas, e que Menger é definido usando coberturas abertas arbitrárias. O caso ordinal fornece e prova os requisitos de contabilidade, compacidade de [0,ω], injetividade e isolamento dos valores finitos. As únicas hipóteses matemáticas do teorema final são as duas desigualdades ordinais.

Não foi encontrado erro na solução do intervalo indicado. A compilação é evidência formal da declaração codificada, sob as definições e os fundamentos registrados. A leitura do problema original e sua correspondência com a codificação continuam sendo uma verificação matemática; a compilação não estabelece originalidade, aceitação editorial ou parecer humano independente.

A proposição abstrata de transferência por subespaço fechado não é formalizada separadamente. O teorema principal formalizado usa o argumento direto da imagem compacta fixa. O caso geral inclui α = ω+1.

Esta recompilação completa dos módulos supera a limitação da execução anterior, que verificou os corpos reunidos em um único arquivo após interromper a compilação modular. Os registros anteriores continuam sendo históricos; os arquivos desta pasta documentam a nova execução.

Registros completos: `verification.json` e `FullAudit.log`, acompanhados dos oito logs dos módulos.
